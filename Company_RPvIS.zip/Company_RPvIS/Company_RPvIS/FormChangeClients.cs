﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Company_RPvIS
{
    public partial class FormChangeClients : Form
    {
        private NpgsqlConnection con;
        private string conString =
            "Host = 127.0.0.1; Username = postgres; Password = ''; Database = Orders";
        public FormChangeClients()
        {
            InitializeComponent();
            con = new NpgsqlConnection(conString);
            con.Open();
            loadClients();

        }

        private void loadClients()
        {
            DataTable dt = new DataTable();
            NpgsqlDataAdapter adap = new NpgsqlDataAdapter("SELECT * FROM clients", con);
            adap.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tbLastname.Text = dataGridView1.SelectedCells[1].Value.ToString();
            tbName.Text = dataGridView1.SelectedCells[2].Value.ToString();
            tbSurname.Text = dataGridView1.SelectedCells[3].Value.ToString();
            tbPassport.Text = dataGridView1.SelectedCells[4].Value.ToString();
            tbPhone.Text = dataGridView1.SelectedCells[5].Value.ToString();
            tbAddress.Text = dataGridView1.SelectedCells[6].Value.ToString();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE clients SET lastname=@lastname, name=@name, surname=@surname, passport=@passport, phone = @phone, address = @address WHERE id = @id";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            cmd.Parameters.AddWithValue("lastname", this.tbLastname.Text);
            cmd.Parameters.AddWithValue("name", this.tbName.Text);
            cmd.Parameters.AddWithValue("surname", this.tbSurname.Text);
            cmd.Parameters.AddWithValue("passport", this.tbPassport.Text);
            cmd.Parameters.AddWithValue("phone", this.tbPhone.Text);
            cmd.Parameters.AddWithValue("address", this.tbAddress.Text);
            int id = int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            cmd.Parameters.AddWithValue("id", id);
            cmd.Prepare();
            cmd.ExecuteNonQuery();

            loadClients();

            this.tbLastname.Text = "";
            this.tbName.Text = "";
            this.tbSurname.Text = "";
            this.tbPassport.Text = "";
            this.tbPhone.Text = "";
            this.tbAddress.Text = "";
        }
    }
}
