﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Company_RPvIS
{
    public partial class FormChangeContracts : Form
    {
        bool fl = false;
        private NpgsqlConnection con;
        private string conString =
            "Host = 127.0.0.1; Username = postgres; Password = ''; Database = Orders";
        public FormChangeContracts()
        {
            InitializeComponent();
            con = new NpgsqlConnection(conString);
            con.Open();
            loadContracts();

            string sql = "SELECT name, surname, lastname FROM clients";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            NpgsqlDataReader reader = cmd.ExecuteReader();
            comboBoxClient.Items.Clear();
            while (reader.Read())
            {
                comboBoxClient.Items.Add(reader.GetString(0) + " " + reader.GetString(1) + " " + reader.GetString(2));
            }
            reader.Close();

            string sql1 = "SELECT name FROM products";
            NpgsqlCommand cmd1 = new NpgsqlCommand(sql1, con);
            NpgsqlDataReader reader1 = cmd1.ExecuteReader();
            comboBoxProduct.Items.Clear();
            while (reader1.Read())
            {
                comboBoxProduct.Items.Add(reader1.GetString(0));
            }
            reader1.Close();

            comboBoxPaymentType.Items.Clear();
            comboBoxPaymentType.Items.Add("Наличные");
            comboBoxPaymentType.Items.Add("Карта");

        }

        private void loadContracts()
        {

            DataTable dt = new DataTable();
            NpgsqlDataAdapter adap = new NpgsqlDataAdapter("SELECT * FROM contracts", con);
            adap.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            string sql = "SELECT id, name, surname, lastname FROM clients";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            NpgsqlDataReader reader = cmd.ExecuteReader();
            //int client_id = 0;
            while (reader.Read())
            {
                if (int.Parse(dataGridView1.SelectedCells[1].Value.ToString()) == int.Parse(reader.GetValue(0).ToString()))
                {
                    comboBoxClient.SelectedItem = reader.GetString(1) + " " + reader.GetString(2) + " " + reader.GetString(3);
                }
            }
            reader.Close();

            string sql1 = "SELECT id, name FROM products";
            NpgsqlCommand cmd1 = new NpgsqlCommand(sql1, con);
            NpgsqlDataReader reader1 = cmd1.ExecuteReader();
            //int product_id = 0;
            while (reader1.Read())
            {
                //comboBoxTour.Items.Add(reader.GetString(0));
                if (dataGridView1.SelectedCells[2].Value.ToString() == reader1.GetValue(0).ToString())
                {
                    comboBoxProduct.SelectedItem = reader1.GetString(1);
                }
            }
            reader1.Close();


            //this.comboBoxClient.Text = dataGridView1.SelectedCells[1].Value.ToString();
            //this.comboBoxProduct.Text = dataGridView1.SelectedCells[2].Value.ToString();
            this.dateTimePickerDate.Text = dataGridView1.SelectedCells[3].Value.ToString();
            this.numericUpDownCount.Value = int.Parse(dataGridView1.SelectedCells[4].Value.ToString());
            this.tbSum.Text = dataGridView1.SelectedCells[5].Value.ToString();
            this.comboBoxPaymentType.Text = dataGridView1.SelectedCells[6].Value.ToString();
            this.checkBoxIsCompleted.Checked = Convert.ToBoolean(dataGridView1.SelectedCells[7].Value);
            fl = true;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            string sql = "SELECT id, name, surname, lastname FROM clients";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            NpgsqlDataReader reader = cmd.ExecuteReader();
            int client_id = 0;
            while (reader.Read())
            {
                //comboBoxTour.Items.Add(reader.GetString(0));
                if (comboBoxClient.SelectedItem.ToString() == reader.GetString(1) + " " + reader.GetString(2) + " " + reader.GetString(3))
                {
                    client_id = Convert.ToInt32(reader.GetValue(0));
                }
            }
            reader.Close();

            string sql1 = "SELECT id, name FROM products";
            NpgsqlCommand cmd1 = new NpgsqlCommand(sql1, con);
            NpgsqlDataReader reader1 = cmd1.ExecuteReader();
            int product_id = 0;
            while (reader1.Read())
            {
                //comboBoxTour.Items.Add(reader.GetString(0));
                if (comboBoxProduct.SelectedItem.ToString() == reader1.GetString(1))
                {
                    product_id = Convert.ToInt32(reader1.GetValue(0));
                }
            }
            reader1.Close();

            string sql2 = "UPDATE contracts SET client_id = @client_id, product_id = @product_id, pay_date = @pay_date, count = @count, sum = @sum, payment_type = @payment_type, isCompleted = @isCompleted WHERE id = @id";
            NpgsqlCommand cmd2 = new NpgsqlCommand(sql2, con);
            cmd2.Parameters.AddWithValue("client_id", client_id);
            cmd2.Parameters.AddWithValue("product_id", product_id);
            cmd2.Parameters.AddWithValue("pay_date", this.dateTimePickerDate.Value);
            cmd2.Parameters.AddWithValue("count", int.Parse(this.numericUpDownCount.Value.ToString()));
            cmd2.Parameters.AddWithValue("sum", decimal.Parse(this.tbSum.Text));
            cmd2.Parameters.AddWithValue("payment_type", this.comboBoxPaymentType.SelectedItem.ToString());
            cmd2.Parameters.AddWithValue("isCompleted", this.checkBoxIsCompleted.Checked);
            int id = int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            cmd2.Parameters.AddWithValue("id", id);
            cmd2.Prepare();
            cmd2.ExecuteNonQuery();

            loadContracts();

            this.comboBoxClient.Text = "";
            this.comboBoxProduct.Text = "";
            this.dateTimePickerDate.Text = "";
            this.numericUpDownCount.Value = 0;
            this.tbSum.Text = "";
            this.comboBoxPaymentType.Text = "";
            this.checkBoxIsCompleted.Checked = false;
        }

        private void numericUpDownCount_ValueChanged(object sender, EventArgs e)
        {
            if (fl == true)
            {
                string sql = "SELECT name, price FROM products";
                NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
                NpgsqlDataReader reader = cmd.ExecuteReader();
                decimal pr = 0;
                while (reader.Read())
                {
                    //comboBoxTour.Items.Add(reader.GetString(0));
                    if (comboBoxProduct.SelectedItem.ToString() == reader.GetString(0))
                    {
                        pr = Decimal.Parse(reader.GetValue(1).ToString());
                    }
                }
                reader.Close();


                tbSum.Text = (numericUpDownCount.Value * pr).ToString();
            }
        }
    }
}
